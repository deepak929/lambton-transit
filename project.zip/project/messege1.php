
<html>
 <style>
body  {
    background-image: url("img/bus.jpg");
    background-color: #cccccc;
}
</style>
<body>
 <header>
      <h1><p style="color:red;">ADMIN AREA</p></h1>
    </header>
	
 <div class="container">
      <div class="columns">
        <div class="column col-10 col-mx-auto">

          <form action="messege.php" method="POST" class="form-group">
            <h3>Message</h3>
            <label class="form-label" for="Messege"><b><p style="color:yellow;">Write Messege</p></b></label>
            <input type="text" name="Messege" value="" /></br></br>
			
            <p>
              <input type="submit" value="Send" />
            </p>

            </form>

          <!-- the form to add a new employee -->
         
          <a href="employees.php" class="btn">Go Back </a>

        </div> <!--//col-10-->
      </div> <!--//columns -->
    </div> <!--// container -->
	</body>
</html>