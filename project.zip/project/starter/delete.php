<?php
  if (isset($_GET["id"]) == FALSE) {
    // missing an id parameters, so
    // redirect person back to add employee page
    header("Location: " . "employees.php");
    exit();
  }

  // save the ID so you can use it later
  $id = $_GET["id"];

  // check for a POST request
  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // @TODO: your database code should  here
    //---------------------------------------------------
	$dbhost = "localhost";
	$dbuser = "root";
	$dbpass = "";
	$dbname = "cestar";

	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	if (mysqli_connect_errno())
	{
	  echo "Failed to connect to MySQL: " . mysqli_connect_error();
	  exit();
	}
	
	$sql 	 = "DELETE FROM EMPLOYEES ";
	$sql 	.= "WHERE id= '" . $id . "'";
	$sql    .= "LIMIT 1";

	$results = mysqli_query($connection, $sql);
				
	if ($results == FALSE) {
		// there was an error in the sql 
		echo "Database query failed. <br/>";
		echo "SQL command: " . $query;
		exit();
	}

    //---------------------------------------------------

    // @TODO: delete these two statements after you are done adding your database code
    echo "I got a POST request! <br/>";
    print_r($_POST);
	
  }

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="../css/spectre.min.css">
    <link rel="stylesheet" href="../css/spectre-exp.min.css">
    <link rel="stylesheet" href="./css/spectre-icons.min.css">
  </head>
  <body>
    <header>
      <h1> ADMIN AREA </h1>
    </header>

    <nav>
      <ul>
        <li>
          <a href="index.php">Home</a>
        </li>
        <li>
          <a href="employees.php">Employees</a>
        </li>
      </ul>
    </nav>

    <div class="container">
      <div class = "columns">
        <div class="column col-10 col-mx-auto">

          <!-- @TODO: Ask user to confirm they want to get delete a person! -->
       <h3> Are you sure you want to delete....!</h3> 
	   <form action = <?php echo "delete.php@id=" . $id ?>>
	   
	   </form><form action = "<?php echo "delete.php?id=" . $id; ?>" method ="POST">
				<button type="submit" name="choice"> Yes! </button>
			</form>

        </div> <!--// col-12 -->
      </div> <!-- // column -->
    </div> <!--// container -->

    <footer>
      &copy; <?php echo date("Y") ?> Cestar College
    </footer>

  </body>
</html>
