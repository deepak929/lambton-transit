<?php
if($_SERVER['REQUEST_METHOD'] == 'POST') {
  // run this code if you get a POST
  echo "<h2> I got a POST request! </h2>";
}
else if ($_SERVER["REQUEST_METHOD"] == "GET") {
  // run this code if you get a GET request!
  echo "<h2> I got a GET REQUEST! </h2>";
}
?>
