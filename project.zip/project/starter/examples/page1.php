<!-- This HTML will always run. Doesn't matter if you have a POST or GET -->
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">

  </head>
  <body>

    <div class="container">
      <div class="columns">
        <div class="column col-10 col-mx-auto">

          <!-- @TODO: Fil in the ACTION and METHOD -->
          <form action="page2.php" method="POST" class="form-group">

            <label class="form-label" for="firstName">First Name</label>
            <input type="text" name="firstName" value="" />

            <p>
              <input type="submit" value="GO GO GO GO!" />
            </p>
          </form>


        </div> <!--//col-10-->
      </div> <!--//columns -->
    </div> <!--// container -->

  </body>
</html>
