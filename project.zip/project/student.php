
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="css/spectre.min.css">
    <link rel="stylesheet" href="css/spectre-exp.min.css">
    <link rel="stylesheet" href="css/spectre-icons.min.css">
  </head>
  <style>
body  {
    background-image: url("img/bus.jpg");
    background-color: #cccccc;
}
.table  {
    background-color: #fff;
}
</style>
  <body>
    <header>
      <h3> STUDENT BUS SERVICES </h3>
    </header>

    <?php

      // 1 - Database information
      $dbhost = "localhost";
      $dbuser = "root";
      $dbpass = "";
      $dbname = "cestar";

      // 2 - Connect to the database and handle any connection errors
      $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

      if (mysqli_connect_errno())
      {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
      }

      // 3 - Make the SQL query and send to database
      $query = "SELECT * FROM employees";

      $results = mysqli_query($connection, $query);

      // 4 - Handle the response from database
      if ($results == FALSE) {
        echo "Database query failed. <br/>";
        echo "SQL command: " . $query;
        exit();
      }
    ?>

    <div class="container">
      <div class = "columns">
        <div class="column col-10 col-mx-auto">
		  
          <table class="table">
            <tr>
              <th>Bus_ID</th>
              <th>From</th>
              <th>To</th>
              <th>Starting Time</th>
			  <th> Next Bus</th>
            </tr>

            <!-- we got a results from the database, so put them into the table -->
            <?php while ($employee = mysqli_fetch_assoc($results)) { ?>
			<?php
				$now = new DateTime();
				$timings = $employee['hire_date'];
				$futureDate = new DateTime($timings);
				$diff = date_diff($now, $futureDate);
			?>
              <tr>
                <td><?php echo $employee['id']; ?></td>
                <td><?php echo $employee['first_name']; ?></td>
                <td><?php echo $employee['last_name']; ?></td>
				<td><?php echo $employee['hire_date']; ?></td>
                <td><?php echo  $diff->format("%h hours %i minutes")?></td>
              </tr>
            <?php } ?>

          </table>


        </div> <!--// col-12 -->
      </div> <!-- // column -->
    </div> <!--// container -->

    
    <?php
      // clean up and close database
      mysqli_free_result($results);
      mysqli_close($connection);
    ?>

  </body>
</html>
