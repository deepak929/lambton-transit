<?php include_once 'header.php'; ?>
	<section class="main-container">
	<div class="container">
	<div class=""row>
	<div align="Right-align">
	<?php
	if (isset($_SESSION['u_id']))
	{
echo  '<form action="index1.php" method="POST">
                   <div align="center">
	              <button type="submit" name="submit">Go To Bus Services</button>
		          </div>
				  </form>';
	}
	
	?>
	</div>
	</div>
	</div>
	</section>
<?php include_once 'footer.php'; ?>
    

    
