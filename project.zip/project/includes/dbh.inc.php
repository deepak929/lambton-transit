<?php 

$dbServername = "localhost";
$dbUsername = "root";
$dbPssword = "";
$dbName = "loginsystem";

$connection = mysqli_connect($dbServername, $dbUsername, $dbPssword, $dbName);