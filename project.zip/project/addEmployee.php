
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="css/spectre.min.css">
    <link rel="stylesheet" href="css/spectre-exp.min.css">
    <link rel="stylesheet" href="css/spectre-icons.min.css">
  </head>
   <style>
body  {
    background-image: url("img/bus.jpg");
    background-color: #cccccc;
}
</style>
  <body>
    <header>
      <h1> ADMIN AREA </h1>
    </header>
    <nav>
      <ul>
        <li>
          <a href="index.php"><b>Home</b></a>
        </li>
        <li>
          <a href="employees.php"><b>Bus Route</b></a>
        </li>
		<li>
          <a href="messege1.php"><b>Send Message</b></a>
        </li>
      </ul>
    </nav>

    <div class="container">
      <div class="columns">
        <div class="column col-10 col-mx-auto">


          <!-- the form to add a new employee -->
          <form action="create.php" method="POST" class="form-group">

            <label class="form-label" for="firstName"><b>From</b></label>
            <input type="text" name="firstName" value="" /></br>


            <label class="form-label" for="lastName"><b>To</b></label>
            <input type="text" name="lastName" value="" /></br>

            <label class="form-label" for="hireDate"><b>Starting Date</b></label>
            <input type="text" name="hireDate" value="" /></br></br>

            <p>
              <input type="submit" value="Add Route" />
            </p>
          </form>

          <a href="employees.php" class="btn">Go Back </a>

        </div> <!--//col-10-->
      </div> <!--//columns -->
    </div> <!--// container -->


  </body>
</html>
