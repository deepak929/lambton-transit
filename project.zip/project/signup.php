<?php include_once 'header.php'; ?>
<style>
body  {
    background-image: url("img/bus.jpg");
    background-color: #cccccc;
}
</style>
<body>
	<section class="container">
	<div class="row">
	<div align="center">
	</br>
	</br>
	<h2><p style="color:blue;"><b>REGISTER</b></p></h2>
		    <form class="signup-form" action="includes/signup.inc.php" method="POST">
	      <input type="text" name="first" placeholder="Firstname"></br></br>
	      <input type="text" name="last" placeholder="Lastname"></br></br>
		  <input type="text" name="email" placeholder="E-mail"></br></br>
		  <input type="text" name="uid" placeholder="Username"></br></br>
		  <input type="password" name="pwd" placeholder="password"></br></br>
		  <button type="submit" name="submit" align="center">Sign up </button>
	    </form>
	</div>
	</div>
	</section>
	</body>
<?php include_once 'footer.php'; ?>