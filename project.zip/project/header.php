<?php session_start(); 
?>
<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="css/spectre.min.css">
    <link rel="stylesheet" href="css/spectre-exp.min.css">
    <link rel="stylesheet" href="css/spectre-icons.min.css">
  </head>
  <style>
body  {
    background-image: url("img/bus.jpg");
    background-color: #cccccc;
}
</style>
  <body>
    <header>
       <nav>
 <div class="container">
	 <div  class="row">
        <div class="col-2"> <a href="index.php"><img src="img/logo.png" style="max-width:150px;"></a>
        </div>
	 <?php
	     if (isset($_SESSION['u_id']))
		 {
			echo  '<form action="includes/logout.inc.php" method="POST">
	                  <div align="right"> 
				   <button type="submit" name="submit">logout</button>
				   </div>
		           </form>';
		 }else{
			echo '<form action="includes/login.inc.php" method="POST">
			    <div align="right">
			  <input type="text" name="uid" placeholder="username">
			  <input type="password" name="pwd" placeholder="password">
			  <button type="submit" name="submit">login</button>
			    <a href="signup.php"><b>Sign up</b></a>
			   </div>
			</form>';
			 
		 }
		 ?>
		 </div>
	    </div>
 </nav>
    </header>
		  </body>
</html>
