<html>
 <style>
body  {
    background-image: url("img/bus.jpg");
    background-color: #cccccc;
}
</style>
<body>
<div class="container">
<?php
if($_SERVER['REQUEST_METHOD'] == 'POST') {

  // Get the form values that were sent by addEmployee.php
  $first = $_POST['firstName'];
  $last = $_POST['lastName'];
  $hire = $_POST['hireDate'];

  // @TODO: your database code should  here
      $dbhost = "localhost";
      $dbuser = "root";
      $dbpass = "";
      $dbname = "cestar";
	  $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	  
       if (mysqli_connect_errno())
        {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
		}
		// create sql
   $sql  =  "INSERT INTO employees ";
   $sql   .= "(first_name,last_name,hire_date)";
   $sql   .= "VALUES ";
   $sql   .="(";
   $sql   .= "'" . $first . "', ";
   $sql   .= "'" . $last . "', ";
   $sql   .= "'" . $hire . "'";
   $sql   .= ")";
   
 $results = mysqli_query($connection, $sql);
  
  if($results == TRUE)
  {
	  echo "<h1> success!</h1>";
	  
  }
  else{
  echo "database query failed. <br/>";
  echo "SQL command: " . $query;
  exit();
  }
   
  // @TODO: delete these two statement after your add your db code
  echo "I got a POST request! <br />";
  print_r($_POST);


} else {

  // you got a GET request, so
  // redirect person back to add employee page
  header("Location: " . "addEmployee.php");
  exit();
}
?>
</div>
</body>
</html>