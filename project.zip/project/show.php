
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="css/spectre.min.css">
    <link rel="stylesheet" href="css/spectre-exp.min.css">
    <link rel="stylesheet" href="css/spectre-icons.min.css">
  </head>
   <style>
body  {
    background-image: url("img/bus.jpg");
    background-color: #cccccc;
}
</style>
  <body>
    <header>
      <h1> ADMIN AREA </h1>
    </header>

    <nav>
      <ul>
        <li>
          <a href="index.php"><b>Home</b></a>
        </li>
        <li>
          <a href="employees.php"><b>Bus Route</b></a>
        </li>
      </ul>
    </nav>

    <div class="container">
      <div class="column">
        <div class="column col-10 col-mx-auto">
          <?php

            if (isset($_GET["id"]) == FALSE) {
              echo "<p>ID is missing </p>";
            }
            else {
              // get the id from the URL
              $id = $_GET["id"];
              echo $id;
              echo "<br />";

              // @TODO: your database code should go somewhere here
              //---------------------------------------------------
      $dbhost = "localhost";
      $dbuser = "root";
      $dbpass = "";
      $dbname = "cestar";
	  $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	  
       if (mysqli_connect_errno())
        {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
		}
		
		$sql  = "SELECT * FROM EMPLOYEES ";
       $sql .= "WHERE id= '" . $id . "'"; 
	   
       $results = mysqli_query($connection, $sql);
  
  if($results == FALSE)
  {
  echo "database query failed. <br/>";
  echo "SQL command: " . $query;
  exit();
  }
  
  $person = mysqli_fetch_assoc($results);

              //---------------------------------------------------


              // output the results to the screen
              echo "<p><strong>From: </strong>" . $person["first_name"] . "</p>";
              echo "<p><strong>To: </strong>" . $person["last_name"]. "</p>";
              echo "<p><strong>Time: </strong>" . $person["hire_date"] . "</p>";

              echo "<br/>";


            }
          ?>

          <p>
            <a href="employees.php" class="btn">Go Back</a>
          </p>

        </div> <!--//col-10-->
      </div> <!--//columns -->
    </div> <!--// container -->

    
  </body>
</html>
