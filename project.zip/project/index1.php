
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="css/spectre.min.css">
    <link rel="stylesheet" href="css/spectre-exp.min.css">
    <link rel="stylesheet" href="css/spectre-icons.min.css">
  </head>
  <style>
  body  {
    background-image: url("img/bus.jpg");
    background-color: #cccccc;
}
</style>
  <body>
    <header>
      <h3> ADMIN AREA </h3>
    </header>
  <div class="container">
      <div class = "columns">
    <nav>
      <ul>
        <li>
          <a href="index.php"><b>Home</b></a>
        </li>
        <li>
          <a href="employees.php"><b>Bus Routes</b></a>
        </li>
		<li>
          <a href="messege1.php"><b>Send Message</b></a>
        </li>
      </ul>
    </nav>

  

          <?php

          ?>

      </div> <!-- // column -->
    </div> <!--// container -->

   
  </body>
</html>
