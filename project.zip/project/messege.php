<html>
 <style>
body  {
    background-image: url("img/bus.jpg");
    background-color: #cccccc;
}
</style>
<body>
<div class="container">
<?php
require __DIR__ . '/twilio-php-master/Twilio/autoload.php';

use Twilio\Rest\Client;

if($_SERVER['REQUEST_METHOD'] == 'POST') 
{
	 $message = $_POST['Messege'];

echo '<span style="color:#B8B8AA;text-align:center;">Sending SMS! </br></span>';
// Your Account SID and Auth Token from twilio.com/console
$account_sid = 'ACa28109ddf3f8efd9375913ba59beb820';
$auth_token = 'a4c3d53091e9c7859d1bcb575622bfd1';

// A Twilio number you own with SMS capabilities
$twilio_number = "+15873177702";

$client = new Client($account_sid, $auth_token);
$client->messages->create(
    // Where to send a text message (your cell phone?)
    '+16475490465',
    array(
        'from' => $twilio_number,
        'body' => $message,
    )
);

echo '<span style="color:#B8B8AA;text-align:center;">Done sending SMS! <br></span>';
}
?>
</div>
</body>
</html>
